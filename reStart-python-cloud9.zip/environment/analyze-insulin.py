"""Preparing to Analyze Insulin with Python"""
import re

file = open("/home/ec2-user/environment/preproinsulin-seq.txt",'r')
data = file.read()

my_string = re.sub(r'[^\w]', '',data)
sol = re.sub(r'[~^0-9]','',my_string)
new_string = re.sub(r'ORIGIN','',sol)
print(new_string)

text_file = open("/home/ec2-user/environment/preproinsulin-seq-clean.txt",'w')
text_file.write(new_string)

count = 0
for i in new_string:
    if(i.islower()):
        count = count+1
print("The number of characters is:",count)

first_char = new_string[0:25]
print('signal sequence:',first_char)
text_file = open("/home/ec2-user/environment/Isinsulin-seq-clean.txt",'w')
text_file.write(first_char)
text_file.close()

second_char = new_string[26:55]
print('signal sequence:',second_char)
text_file = open("/home/ec2-user/environment/binsulin-seq-clean.txt",'w')
text_file.write(second_char)
text_file.close()

third_char = new_string[56:90]
print('signal sequence:',third_char)
text_file = open("/home/ec2-user/environment/cinsulin-seq-clean.txt",'w')
text_file.write(third_char)
text_file.close()

fourth_char = new_string[91:110]
print('signal sequence:',fourth_char)
text_file = open("/home/ec2-user/environment/dinsulin-seq-clean.txt",'w')
text_file.write(fourth_char)
text_file.close()






