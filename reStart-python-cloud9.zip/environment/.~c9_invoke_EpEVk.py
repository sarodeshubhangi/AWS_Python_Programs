"""
Find Prime Numbers and save the result to result.txt file
"""
import re

file = open("/home/ec2-user/environment/result.txt",'w')
for Number in range (1, 250):
    count = 0
    for i in range(2, (Number//2 + 1)):
        if(Number % i == 0):
            count = count + 1
            break

    if (count == 0 and Number != 1):
        print(" %d" %Number, end = '  ')
        
new_Number = Number[1,250]
print('signal sequence:',Number)
text_file.write (str(new_Number))
text_file.close()
        

