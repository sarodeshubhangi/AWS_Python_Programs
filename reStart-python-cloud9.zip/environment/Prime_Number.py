"""
Find Prime Numbers and save the result to result.txt file
"""
import re

file = open("/home/ec2-user/environment/result.txt",'w')
for Number in range (1, 250):
    count = 0
    for i in range(2, (Number//2 + 1)):
        if(Number % i == 0):
            count = count + 1
            break

    if (count == 0 and Number != 1):
        print(" %d" %Number, end = '  ')
        file.write(str(Number) + '\n')
        file.close
        

        
        
'''file1 = open("/home/ec2-user/environment/files/results1.txt","w")

for num in range(1, 255):
   if num > 1:
       if all(num%i!=0 for i in range(1,num)):
           print(num)
           file1.write(str(num) + '\n')
           file1.close'''

